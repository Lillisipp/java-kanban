public class Main {

    public static void main(String[] args) {

        System.out.println("Поехали!");
        Subtask subtask=new Subtask("u","uu",1);
        Epic epic=new Epic("y","yy");
//        public void addSubtask (String name, String description,int epicId){
//            Subtask subtask = new Subtask(generateId(), name, description, epicId);
//            subtasks.put(subtask.getId(), subtask); // Сохраняем подзадачу
//            Epic epic = epics.get(epicId); // Находим эпик по ID
//            if (epic != null) {
//                epic.addSubtask(subtask.getId()); // Добавляем ID подзадачи в список эпика
//                epic.updateStatus(subtasks); // Обновляем статус эпика
//            }
//        }
        System.out.println("Добавление подзадачи: " + subtask);
        System.out.println("ID подзадачи: " + subtask.getId());
      //  System.out.println("Существуют ли эпики: " + epics.containsKey(subtask.getEpicId()));

    }
}
